<template>
	<div>
		<h1>Galería de fotos</h1>
		<Foto />
	</div>
</template>

<script>

	import Foto from "@/component/Foto.vue"

	export default
	{
		
		name: 'Fotos',
		components:
		{
		
			Foto
		
		}
	
	}

</script>
<template>
	<div class="text-center">
		<img alt="Vue logo" src="@/assets/logo.png">
		<h1>Frutas</h1>
	</div>
</template>

<script>

	export default
	{
	
		name: 'Cabecera'
	
	}

</script>
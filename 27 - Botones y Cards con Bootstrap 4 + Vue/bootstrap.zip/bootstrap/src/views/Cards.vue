<template>
	<div class="mt-5">
		<b-button variant="success">Texto</b-button>
		<b-button variant="info">Texto</b-button>
		<b-button variant="danger">Texto</b-button>
		<b-button variant="primary">Texto</b-button>
		<b-button variant="warning">Texto</b-button>
		<b-button variant="dark">Texto</b-button>
		
		<b-row>
			<b-col cols="12" md="6">
				<b-card img-src="https://placekitten.com/1000/300" img-alt="Card image" img-top>
					<b-card-text>
					  Some quick example text to build on the card and make up the bulk of the card's content.
					</b-card-text>
				</b-card>
			</b-col>
			<b-col cols="12" md="6">
				<b-card img-src="https://placekitten.com/1000/300" img-alt="Card image" img-top>
					<b-card-text>
					  Some quick example text to build on the card and make up the bulk of the card's content.
					</b-card-text>
				</b-card>
			</b-col>
		</b-row>
	</div>
</template>

<script>

	export default
	{
	
		name: 'Cards'
	
	}

</script>
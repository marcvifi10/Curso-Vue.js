<template>
	<div class="mt-5">
		<b-row>
			<b-col cols="12" md="6">
				<p>Esto es un ejemplo</p>
			</b-col>
			<b-col cols="12" md="6">
				<p>Esto es un ejemplo</p>
			</b-col>
		<b-row>
	</div>
</template>
<script>

	export default
	{
	
		name: 'Grid'
	
	}
	
</script>
<template>
	<div class="mt-5">
		<h1>Formulario</h1>
		
		<form>
			<b-row>
				<b-col md="6">
					<b-form-input type="number"></b-form-input>
					<b-form-input type="text" v-model="texto" :state="comprobar"></b-form-input>
					<small>Mínimo 3 carácteres</small>
					<b-form-input type="text" v-model="texto" :state="true"></b-form-input>
				</b-col>
			</b-row>
		</form>
		<hr>
		<p>Texto: {{ texto }}</p>
		
	</div>
</template>

<script>

	export default
	{
	
		name: 'Form',
		data()
		{
		
			return
			{
			
				texto: ''
			
			}
		
		},
		computed: 
		{
		
			comprobar()
			{
			
				return this.texto.length > 2 ? true : false
			
			}
		
		}
	
	}

</script>
<template>
	<div class="mt-5">
		<h1>Formulario</h1>
		
		<form>
			<b-row>
				<b-col md="3">
					<b-form-input type="number"></b-form-input>
					<b-form-input type="text" v-model="texto" :state="comprobar"></b-form-input>
					<small>Mínimo 3 carácteres</small>
					<b-form-input type="text" v-model="texto" :state="true"></b-form-input>
				</b-col>
				<b-col md="3">
					 <b-form-select v-model="select" :options="animales"></b-form-select>
					 <p>Seleccion: {{ select }}</p>
				</b-col>
				<b-col md="3">
					<b-form-radio v-model="selected" name="some-radios" value="A">Option A</b-form-radio>
					<b-form-radio v-model="selected" name="some-radios" value="B">Option B</b-form-radio>
				</b-col>
				<b-col md="3">
					<b-form-checkbox
					  id="checkbox-1"
					  v-model="status"
					  name="checkbox-1"
					  value="accepted"
					  unchecked-value="not_accepted"
					>
					  I accept the terms and use
					</b-form-checkbox>

					<div>State: <strong>{{ status }}</strong></div>
				</b-col>
			</b-row>
		</form>
		<hr>
		<p>Texto: {{ texto }}</p>
		
	</div>
</template>

<script>

	export default
	{
	
		name: 'Form',
		data()
		{
		
			return
			{
			
				texto: '',
				select: null,
				animales: 
				[
				
					{ value: null, text: 'Seleccione un animal' },
					{ value: 'perro', text: 'Perro' },
					{ value: 'gato', text: 'Gato' },
					{ value: 'pato', text: 'Pato' },
				],
				selected: '',
				status: 'not_accepted'
			
			}
		
		},
		computed: 
		{
		
			comprobar()
			{
			
				return this.texto.length > 2 ? true : false
			
			}
		
		}
	
	}

</script>